     <!--/ Section Contact-Footer Star /-->
     <section
      class="paralax-mf footer-paralax bg-image sect-mt4 route"
      style="background-image: url(img/geometric-gradient-futuristic-background_23-2149116406.jpg)"
    >
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="contact-mf">
              <div id="contact" class="box-shadow-full">
                <div class="row">
                  <div class="col-md-6">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        برای ما پیام ارسال کنید
                      </h5>
                    </div>
                    <div>
                      <form action=""  id="message_form">
                        <div id="sendmessage">
                        پیام شما با موفقیت ارسال شد
                        </div>
                        <div id="errormessage"></div>
                        <div class="row">
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input name="fullname" placeholder="نام کامل خود را وارد کنید : " autocomplete="off" type="text" class="form-control">
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input name="email" placeholder="ایمیل خود را وارد کنید :" autocomplete="off" type="text" class="form-control">
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input name="subject" placeholder="موضوع خود را وارد کنید :" autocomplete="off" type="text" class="form-control">
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">
                            <div class="form-group">
                             <textarea name="text" placeholder="متن پیام خود را وارد کنید :" autocomplete="off" type="text" class="form-control" rows="5"></textarea>
                            </div>
                          </div>
                          <div class="col-md-12 mb-3">                        
                                <img id="demo" width="35px" src="img/Spinning arrows (1).gif" alt="gif ">
                                <button class="btn-footer">
                                <span class="border-btn top-btn"></span>
                                <span class="border-btn right-btn"></span>
                                <span class="border-btn bottom-btn"></span>
                                <span class="border-btn left-btn"></span> ارسال
                                </button> 
                                <!-- <button class="btn btn-primary">ارسال پیام</button> -->
                          </div>
                            <div class="col-md-12 mb-3">
                             <p id="resultM"></p>
                            </div> 
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="title-box-2 pt-4 pt-md-0">
                      <h5 class="title-left">
                        با ما در تماس باشید
                      </h5>
                    </div>
                    <div class="more-info">
                      <p class="lead">
                      <?php echo $setting['intro']; ?>
                      </p>
                      <ul class="list-ico">
                        <li>
                          <span class="ion-ios-location"></span><?php echo $setting['address']; ?>
                        </li>
                        <li>
                          <span class="ion-ios-telephone"></span> <?php echo $setting['phone']; ?>
                        </li>
                        <li>
                          <span class="ion-email"></span> <?php echo $setting['email']; ?>
                        </li>
                      </ul>
                    </div>
                    <div class="media">
                      <ul>
                      <li>
                        <div class="ico-circlef">
                           <a href="<?php echo $setting['facebook']; ?>"><span class="span-circlef"><i class="fa fa-facebook"></i></span></a>
                        </div>
                      </li>
                      <li>
                        <div class="ico-circlef">
                          <a href="<?php echo $setting['instagram']; ?>"><span class="span-circlef"><i class="fa fa-instagram"></i></span></a>
                        </div>
                      </li>
                      <li>
                         <div class="ico-circlef">
                      <a href="<?php echo $setting['twitter']; ?>"><span class="span-circlef"><i class="fa fa-twitter"></i></span></a>
                        </div>
                      </li>
                      <li>
                        <div class="ico-circlef">
                          <a href="<?php echo $setting['pinterest']; ?>"><span class="span-circlef"><i class="fa fa-pinterest"></i></span></a>
                        </div>
                      </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer>
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <div class="copyright-box">
                <p class="copyright text-center">
                  &copy; <?php echo $setting['copyright']; ?> 
                </p>
                <div class="credits">
                   
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </section>
    <!--/ Section Contact-footer End /-->
 
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
    <div id="preloader"></div>
 
 
 
 

    <!-- JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/jquery/jquery-migrate.min.js"></script>
    <script src="lib/popper/popper.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/counterup/jquery.waypoints.min.js"></script>
    <script src="lib/counterup/jquery.counterup.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/typed/typed.min.js"></script>
    <!-- Contact Form JavaScript File -->
    <script src="contactform/contactform.js"></script>

    <!-- Template Main Javascript File -->
    <script src="js/main.js"></script>


    <script>
  $(document).ready(function(){
    $("#demo").hide();
    $("#message_form").submit(function(event){
      event.preventDefault();
      $("#demo").show(500);
      var info = $(this).serialize();
      $.ajax({
        url:"message.php",
        dataType:"json",
        type:"post",
        data:info,
        success:function(response){
          $("#demo").hide(1000);
          $("#resultM").text(response);
        }
      });
    });
  });
</script>


  </body>
</html>




 
 
 
 
 
 
 
 
 
 
 
 
 
