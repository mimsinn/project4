<!--/ Section Blog Star /-->
<section id="blog" class="blog-mf sect-pt4 route">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="title-box text-center">
          <h3 class="title-a">
          وبلاگ های ما
          </h3>
          <div class="line-mf"></div>
        </div>
      </div>
    </div>
    <div class="row">

      <?php
      $showPost = showPosts2();
      foreach ($showPost as $showP) {
      ?>
        <div class="col-md-4">
          <div class="card card-blog work-box ">
                <div class="card-img  work-img">
                <a href="blog-single.php?id=<?php echo $showP['id']; ?>"><img src="<?php echo $showP['image']; ?>" alt="" class="img-fluid" /></a>
                </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category"><?php if(empty(showSingleCategory($showP['id']))){ echo "دسته بندی نشده";}else {echo showSingleCategory($showP['id']);}; ?></h6>
                </div>
              </div>
              <h3 class="card-title">
                <a href="blog-single.php?id=<?php echo $showP['id']; ?>"><?php echo $showP['title']; ?></a>
              </h3>
              <p class="card-description">
                <a href="blog-single.php?id=<?php echo $showP['id']; ?>">
                  <?php echo $showP['tags']; ?>
                  </a>
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="blog-single.php?id=<?php echo $showP['id']; ?>">
                  <span class="author"><?php echo $showP['author']; ?></span>
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php
      }
      ?>


    </div>
  </div>
</section>
<!--/ Section Blog End /-->