   <div
      class="section-counter paralax-mf bg-image"
      style="background-image: url(img/sl_031420_28950_10.jpg)"
    >
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">

        <?php
         $showC = showNumbers();
        if(mysqli_num_rows($showC) > 0){
          foreach($showC as $showNumber){
        ?>
           <div class="col-sm-3 col-lg-3">
            <div class="counter-box counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"
                  ><i class="<?php echo $showNumber['icon']; ?>"></i
                ></span>
              </div>
              <div class="counter-num">
                <p class="counter"><?php echo $showNumber['count']; ?></p>
                <span class="counter-text"><?php echo $showNumber['title']; ?></span>
              </div>
            </div>
          </div> 
        <?php
        }}
        ?>


         </div>
      </div>
    </div>  
  

