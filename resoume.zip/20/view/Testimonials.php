   <!--/ Section Testimonials Star /-->
   <div
      class="testimonials paralax-mf bg-image"
      style="background-image: url(img/5056413.jpg)"
    >
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="testimonial-mf" class="owl-carousel owl-theme">
              
            
            
            
            
            <?php
              $showComment = showAboutmy();
              foreach($showComment as $comment){
              ?>
            
            <div class="testimonial-box">
                <div class="author-test">
                  <img
                  style="width:150px !important;height:150px !important;box-shadow:0 0 10px #fff;"
                    src="<?php echo $comment['image']; ?>"
                    alt=""
                    class="rounded-circle b-shadow-a"
                  />
                  <span class="author"><?php echo $comment['fullname']; ?></span>
                </div>
                <div class="content-test">
                <p class="description lead "  id="t-text">
                <?php echo $comment['text']; ?>                   
                  </p>
                  <span class="comit"><i class="fa fa-quote-right"></i></span>
                </div>
              </div>
            <?php
              }
            ?>
            </div>
          </div>
        </div>
      </div>
    </div>