    <!--/ Section Portfolio Star /-->
    <section id="work" class="portfolio-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                نمونه کارها
              </h3>
              <p class="subtitle-a text-center text-p">
                نمونه پروژه هایی که وبسایت ما توانسته است آن ها را به بهترین شکل ممکن به مشتری اراعه بدهد
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">


        <?php
        $showSample = showSample2();
        foreach($showSample as $showSample2){
        ?>
          <div class="col-md-4">
            <div class="work-box">
              <a href="<?php echo $showSample2['src']; ?>" data-lightbox="gallery-mf">
                <div class="work-img">
                  <img src="<?php echo $showSample2['src']; ?>" alt="" class="img-fluid" />
                </div>
                <div class="work-content">
                  <div class="row">
                    <div class="col-sm-10">
                      <h2 class="w-title"><?php echo $showSample2['title']; ?></h2>
                      <div class="w-more">
                        <span class="w-ctegory"><?php echo $showSample2['category']; ?></span> /
                        <span class="w-date"><?php echo $showSample2['date']; ?></span>
                      </div>
                    </div>
                    <div class="col-sm-2">
                      <div class="w-like">
                        <span class="ion-ios-plus-outline"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>

          <?php
        }
      ?>
 
        </div>
      </div>
    </section>
    <!--/ Section Portfolio End /-->
