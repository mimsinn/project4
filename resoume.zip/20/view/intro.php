    <!--/ Intro Skew Star /-->
    <div
      id="home"
      class="intro route bg-image"
      style="background-image: url(img/abstract-digital-grid-black-background.jpg)"
    >
      <div class="overlay-itro"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <!-- <p class="display-6 color-d">Hello, world!</p> -->
            <h1  class="intro-title mb-4">ما یک توسعه دهنده هستیم</h1>
            <p class="intro-subtitle">
              <span class="text-slider-items">توسعه دهنده, برنامه نویس, طراح</span
              ><strong class="text-slider"></strong>
            </p>
            <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
          </div>
        </div>
      </div>
    </div>
    <!--/ Intro Skew End /-->



    <?php
$showAbout = showAbout();
$rowAbout = mysqli_fetch_assoc($showAbout);
?>

    <section id="about" class="about-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-sm-6 col-md-5">
                      <div class="about-img">
                        <img
                          src="img/photo_۲۰۲۴-۰۱-۰۲_۲۲-۰۳-۰۰.jpg"
                          class="img-fluid rounded b-shadow-a"
                          alt=""
                        />
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-7">
                      <div class="about-info">
                        <p>
                          <span class="title-s">نام : </span>
                          <span><?php echo $rowAbout['name']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">پروفایل : </span>
                          <span><?php echo $rowAbout['profile']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">ایمیل : </span>
                          <span><?php echo $rowAbout['email']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">تلفن : </span>
                          <span><?php echo $rowAbout['phone']; ?></span>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="skill-mf">


                  
                    <p class="title-s">مهارت ها</p>
                    <?php
                    $showSkill = showSkills();
                    if(mysqli_num_rows($showSkill) > 0){
                    foreach($showSkill as $showSk){
                    ?>
                    <span><?php echo $showSk['title']; ?></span> <span class="pull-left"><?php echo $showSk['volume']; ?>%</span>
                    <div class="progress">
                      <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: <?php echo $showSk['volume']; ?>%"
                        aria-valuenow="90"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                    <?php
                    }}
                    ?>
                  </div>
                </div>



            <?php
            $showAbout = showAbout2();
            $rowAbout = mysqli_fetch_assoc($showAbout);
            ?>
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-sm-6 col-md-5">
                      <div class="about-img">
                        <img
                          src="img/testimonial-2.jpg"
                          class="img-fluid rounded b-shadow-a"
                          alt=""
                        />
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-7">
                      <div class="about-info">
                        <p>
                          <span class="title-s">نام : </span>
                          <span><?php echo $rowAbout['name']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">پروفایل : </span>
                          <span><?php echo $rowAbout['profile']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">ایمیل : </span>
                          <span><?php echo $rowAbout['email']; ?></span>
                        </p>
                        <p>
                          <span class="title-s">تلفن : </span>
                          <span><?php echo $rowAbout['phone']; ?></span>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="skill-mf">



                    <p class="title-s">مهارت ها</p>
                    <?php
                    $showSkill = showSkills2();
                    if(mysqli_num_rows($showSkill) > 0){
                    foreach($showSkill as $showSk){
                    ?>
                    <span><?php echo $showSk['title']; ?></span> <span class="pull-left"><?php echo $showSk['volume']; ?>%</span>
                    <div class="progress">
                      <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: <?php echo $showSk['volume']; ?>%"
                        aria-valuenow="90"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                    <?php
                    }}
                    ?>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
