   <!--/ Section Services Star /-->
   <section id="service" class="services-mf route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                خدمات ما
              </h3>
              <p class="subtitle-a text-center text-p">
            با اطمینان خاطر پروژه های خود را به ما بسپارید تا نگران آینده نباشید
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">

        
        
        
        <?php
      $showService = showServices();
      foreach($showService as $service){
      ?>


          <div class="col-md-4">
              <a href="#">
                <div class="box-services">
                  <img class="img-services" src="<?php echo $service['img']; ?>" alt="">
                 <div class="text-services">
                  <h3 class="title-services"><?php echo $service['title']; ?></h3>
                  <h5 class="sub-title-services"><?php echo $service['text']; ?></h5>
                 </div>
                </div>
              </a>
          </div>
        <?php
      }
        ?>  
        </div>
      </div>
    </section>
    <!--/ Section Services End /-->




