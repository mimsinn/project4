-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 22, 2024 at 06:40 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myresume`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
CREATE TABLE IF NOT EXISTS `about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `profile` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `name`, `profile`, `email`, `phone`) VALUES
(1, 'محسن صادقی', 'backend developer', 'mohsen.saddeeghi@gmail.com', '+989156485263');

-- --------------------------------------------------------

--
-- Table structure for table `about-my`
--

DROP TABLE IF EXISTS `about-my`;
CREATE TABLE IF NOT EXISTS `about-my` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `text` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `about-my`
--

INSERT INTO `about-my` (`id`, `fullname`, `text`, `image`) VALUES
(1, 'محسن صادقی', '                دانشجوی کارشناسی نرم افزار هستم و به مدت چند سال مشغول در \r\n                   حوضیه تست و توسعه  نرافزار بوده ام و مسلط به برنامه نویسی فرانت و بک', 'img/photo_۲۰۲۴-۰۱-۰۲_۲۲-۰۳-۰۰.jpg'),
(2, 'علی اکبری', '                    دانشجوی کارشناسی هوش مصنوعی هستم و به مدت چند سال مشغول در\r\n                    حوضه طراحی ربات های مصنوعی و متخصص پایتون', 'img/testimonial-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `about2`
--

DROP TABLE IF EXISTS `about2`;
CREATE TABLE IF NOT EXISTS `about2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `profile` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `about2`
--

INSERT INTO `about2` (`id`, `name`, `profile`, `email`, `phone`) VALUES
(1, 'علی اکبری\r\n', 'Full Stack Developer', 'ali_ak@gmail.com', '09552775432');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb3_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'DizainRM', 'DizainRM');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`) VALUES
(1, 'سئو ', 'seo'),
(2, 'متلب', 'matlab'),
(3, 'درآمد', 'daramad');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `title`, `link`) VALUES
(1, 'ارتباط با ما', 'contact'),
(2, 'وبلاگ', 'blog'),
(3, 'نمونه کارها', 'work'),
(4, 'خدمات ما', 'service'),
(5, 'درباره ما', 'about'),
(6, 'DizainRM', 'home');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `fullname`, `email`, `subject`, `text`) VALUES
(15, 'gtgtrg', 'gtgt', 'tgtgt', 'tdtg'),
(14, 'vxff', 'v v', 'cvbcb', 'dfgfgf'),
(13, 'رسول', 'رسول', 'رسول', 'رسول');

-- --------------------------------------------------------

--
-- Table structure for table `numbers`
--

DROP TABLE IF EXISTS `numbers`;
CREATE TABLE IF NOT EXISTS `numbers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `count` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `numbers`
--

INSERT INTO `numbers` (`id`, `title`, `count`, `icon`) VALUES
(2, 'افتخارات', '21', 'ion-ribbon-a'),
(3, 'تعداد مشتری ها', '550', 'ion-ios-people'),
(4, 'تجربه کاری', '18', 'ion-ios-calendar-outline'),
(5, 'پروژه های کامل شده', '520', 'ion-checkmark-round');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `category` int NOT NULL,
  `author` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `tags` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `category`, `author`, `text`, `image`, `tags`) VALUES
(1, 'چرا یک سئو کار باید برنامه نویس خوبی باشد؟', 2, 'محسن صادقی', 'همانطور که می دانید سئو یکی از مهم ترین عوامل موفقیت در کسب و کار های اینترنتی می باشد.\r\n\r\nامروزه شاهد بیزینس های فراوانی هستیم که یکی پس از دیگری به دلیل عدم وجود سئو مناسب با شکست رو به رو می شوند؛این امر موجب در آمد بسیار بالا سیو کاران گردیده و بازار کار این متخصصین را رونق بخشیده است.\r\n\r\nاما برای اینکه یک سئو کار خوب باشیم باید چه معیار هایی را رعایت کنیم؟\r\n\r\nبدون شک یک مهندس سئو باید بروز باشد،چراکه علم موتور های جست و جو در جریان های زمانی ساخته می شود یعنی هر روز به آن اضافه شده و اگر شما به عنوان یک متخصص سیو بر پایه علم پیشین خود جلو بروید،بلا شک از حرفه کاری خود عقب خواهید ماند.\r\n\r\nدر ادامه،یک سئو دان باید به خوبی با علم برنامه نویسی آشنایی داشته باشد و حتی بر اساس عقیده شخصی مسلط بودن بر یک زبان برنامه نویسی تحت وب می تواند کمک شایانی به شما کند؛اما چگونه؟\r\n\r\nفرض کنید شما یک آنالیزور سئو هستید؛یکی از نیاز های مبرم شما داشتن وب سایتی برای ارائه مقالات ، محتوای سئو\r\n\r\nو حتی لینک های سئو شده خود می باشد،برای ساخت این وب سایت شما می توانید از روش های گوناگونی چون وردپرس و .... استفاده کنید،اما بهترین آن ها دانش کد نویسی بوده،چون به شما قابلیت خود سازی را می دهد.\r\n\r\nبرای مثال،به جای ساختن یک سایت مپ استاتیک که توانایی تغییر لینک های شناخته شده را تنها از راه تعویض دستی\r\n\r\nبه شما می دهد؛شما می توانید یک اپلیکیشن تحت وب به وسیله زبان برنامه نویسی تحت وب خود بسازید که به صورت خودکار این فرآیند را برای شما انجام دهد.\r\n\r\nدر بسیاری از موقعیت ها به عنوان یک سئو کار،شما می بایست ارتباط های مختلفی را بین گوگل و سایت های مورد هدف خود بر قرار کنید،من  جمله این ارتباط ها می توان به  اولین قدم شما به منظور برقراری سیستم سرچ کنسول اشاره نمود و یا قرار دادن یک بنر خاص به منظور آگاه سازی بیشترمخاطب تحت عنوان استراکچر دیتا؛انجام تمامی این کار ها نیازمند آشنایی حداقله با دستور و کد نویسی می باشد.\r\n\r\nرعایت استاندارد نویسی در زبان اچ تی ام ال که خود مبدأ حرفه ما می باشد می تواند تاثیر به سزایی در افزایش رنک سئو ما داشته باشد.\r\n\r\nگوگل،ربات ها و الگو هایی را در بر داشته که دائما در حال برسی ساختار وب سایت شما هستند،و در حتی در صورت رعایت نکردن بعضی مباحث نظیر تگ هد و ... ممکن است شما را جریمه کرده و اهمیتی برای پیج شما قائل نشوند.\r\n\r\nدر بسیار از مواقع سیستم سئو شما به ارور هایی دچار می شود که تنها به وسیله دانش زبان های کامپیوتری قابل حل می باشد،دانش اچ تی اکسس می توان یکی از این پل های موفقیت باشد.\r\n\r\nزمانی که سیستم شما نیازمند تک دامنه شدن،ریدایرکت،حفظ امنیت کاربری و... باشد،اچ تی اکسس می تواند یکی از ابزار های شما باشد.\r\n\r\nامنیت سایت شما نیز ارتباط گسترده ای با سئو دارد،شاید در ابتدا ارتباط به خصوصی میان این دو پیدا نکنید اما سایت هک شده ای را تصور کنید که رنک بالای خود را از دست داده زیرا اعتماد موتور جست و جو را از دست داده و از لیست متور های خود لینک های شما را حذف نموده است.\r\n\r\nبنابراین سعی کنید در امن ترین حالت کد های سیستمی خود را نوشته و هر گونه  راه نفوذی را از بین ببرید؛این گونه می توانید سایت خود را به بهترین شکل بالا بیاورید.\r\n\r\nدر انتها،سرعت سایت تاثیر گسترده ای بر روی سئو سایت شما دارد؛متخصص سئویی که بداند چگونه کد های خود را روی هم دیگر بگذارد،دیگر مشکلی در زمینه سرعت نخواهد داشت چرا که می داند چگونه بهینه کار خود را پیش ببرد و سایت خود را به گونه ای بسازد که موتور جست و جو گر مورد نظر به بهترین شکل اطلاعات سایت را رندر نماید.\r\n', 'img/WallpaperGram.IR_1554001502_73196', '                   همان طور که میدانید سئو یکی از مهمترین عوامل موفقیت در کسب و کار های اینترنتی می باشد...  \r\n'),
(2, 'نرم افزار متلب چیست و چه کاربردی دارد؟', 1, 'محسن صادقی', 'اگر در هر یک از رشته های مهندسی تحصیل می کنید احتمالا نام نرم افزار متلب به گوش شما آشنا باشد در این مقاله قصد دارم شما را با این نرم افزار قدرتمند و پر توان آشنا کنم پس با من همراه باشید.\r\nتاریخچه\r\n\r\nابتدا اجازه دهید کمی درباره گذشته ی این نرم افزار اطلاعاتی در اختیار شما قرار دهم. (MATLAB) توسط ریاضی دان و برنامه نویسی به نام (Cleve Moler)  بوجود آمد ایده اصلی پیدایش این نرم افزار رساله ی دکترای آقای (Moler) بود. قبل از اینکه (version 1.0) این برنامه انتشار یابد، نرم افزار (MATLAB) یک زبان برنامه نویسی نبوده و فقط برای اجرای محاسبات روی ماتریس ها کاربرد داشت و هیچگونه جعبه ابزار (Toolbox) و برنامه ی خاصی در آن وجود نداشت.\r\n\r\nدر سال 1984 برای اولین بار در کنفرانس کنترل اتوماتیک در شهر لاس وگاس آمریکا به شکل تجاری رونمایی شد و کمپانی (Mathworks) برای توسعه این نرم افزار تشکیل شد. اولین خرید این نرم افزار در همان سال توسط شخصی از دانشگاه ماساچوست (MIT) صورت گرفت. برای پیاده سازی این نرم افزار از زبانهای برنامه نویسی C، C++ و MATLAB استفاده شده است.\r\nMATLAB چیست؟\r\n\r\n(MATLAB) مخفف (MATrix LABoratory) است، یعنی آزمایشگاه ماتریس ها، بدین صورت که همه ی اتفاقات در این نرم افزار در قالب ماتریس رخ می دهد. همانطور که از نام نرم افزار پیداست، آزمایشگاهی بودن آن باعث شده که اکثر محققان و دانشجویان جهت پیشبرد اهداف علمی خود از نرم افزار استفاده کنند. در سایر زبانهای برنامه نویسی چارچوب هایی (Frameworks) برای راحت تر کردن کد نویسی و سرعت بخشیدن به عملکرد برنامه وجود دارند، متلب برای این منظور از جعبه ابزارهایی (Toolbox) استفاده می کند تا علاوه بر موارد فوق یک سری مطالب علمی را جهت استفاده ساده کند.\r\nمتلب مانند سایر زبانهای برنامه نویسی دستورات شرطی، حلقه ها و توابع را در خود جای داده است تا برنامه نویسان به راحتی در این نرم افزار کدنویسی کنند. همچنین متلب از شی گرایی نیز پیروی می کند یعنی می توان در آن کلاس تعریف کرد.\r\n\r\nدر نرم افزار متلب می توان انواع نمودارهای دو بعدی و سه بعدی را رسم کرد. سایر نمودارها خاص مانند هیستوگرام (Histogram)، (Scatter) و... برای رسم شدن دارای دستورات خاصی هستند. علاوه بر موارد فوق شما از قسمت سیمولینک (Simulink) هم می توانید مدارات و بلوک دیاگرام های مختلف را شبیه سازی کنید.\r\nکاربردها\r\n\r\nStatistics and Machine Learning:\r\n\r\nاین جعبه ابزار بسیار سودمند می باشد که شامل توابع زیادی مربوط به آمار و احتمال است. همچنین یکسری مدل های آماده برای یادگیری ماشین در خود جای داده است که برای حل مسائل بسیار مفید است.\r\n\r\nCurve Fitting:\r\n\r\nاین جعبه ابزار به ما کمک می کند که طرح و الگو یک منحنی یا سطوح را به دست آوریم و بتوانیم عملیاتی نظیر انتگرال گیری و ... را روی آن انجام دهیم.\r\n\r\nSignal Processing:\r\n\r\nپردازش سیگنال در شاخه های مختلف مهندسی کاربرد دارد. این جعبه ابزار بسیاری از تبدیل های مهم مثل لاپلاس، Z  و فوریه را در خود جای داده است که می توانند بر روی سیگنال های مختلف اعمال شوند.\r\n\r\nDeep Learning:\r\n\r\nاین جعبه ابزار از زیر مجموعه یادگیری ماشین است که برای تشخیص گفتار، پردازش تصاویر پزشکی و شبکه های عصبی کاربرد دارد.\r\n\r\nFinancial Instruments:\r\n\r\nدر این جعبه ابزار می توان درباره ی مواردی مانند سودآوری، نقدینگی و سایر مفاهیم مالی اطلاعات کسب کرد. همچنین می توان بسیاری از پارامترهای مالی را محاسبه کرد.\r\n\r\nAerospace:\r\n\r\nاین جعبه ابزار جهت تحلیل ناوبری و مصورسازی مسیر پرواز استفاده می شود. همچنین می توان سایر موارد و اصطلاحات مربوط به مهندسی هوافضا را در این جعبه ابزار یافت.\r\n\r\n اگر راجع به این نرم افزار هیچ گونه اطلاعی ندارید پیشنهاد می کنم برای ورود به این دنیای بزرگ دوره ی رایگان آموزش جامع ماتریس ها در متلب  را مشاهده فرمائید.\r\n\r\nاگر به شکل مقدماتی با این نرم افزار آشنایی دارید و می خواهید با زبان برنامه نویسی آن آشنا شوید پیشنهاد من دوره ی آموزش جامع نرم افزار متلب  می باشد.', 'img/WallpaperGram.IR_1571868012_54768.jpg', '          اگر در هر یک از رشته های مهندسی تحصیل می کنید احتمالا نام نرم افزار متلب را شنیده باشید...\r\n'),
(3, 'چگونه به عنوان یک برنامه نویس درآمد بیشتری داشته باشیم؟', 3, 'علی اکبری', 'آیا شما هم علاقه مند به افزایش درآمد خود به عنوان یک برنامه نویس هستید؟ در این مطلب درباره استراتژی های افزایش درآمد برای برنامه نویسان صحبت می کنیم.\r\n\r\nبرنامه نویس بودن می تواند برای هر کسی فوق العاده باشد. در این شغل نه تنها شما اکثر مواقع سرگرم هستید بلکه فرصت های شغلی زیادی برای شما وجود دارد که اکثر آنها نیز دارای حقوق و درآمد بالایی هستند. با این حال برخی از مواقع ممکن است شما نیاز به درآمد بیشتری داشته باشید. ممکن است شما در دوران تحصیل خود باشید و به جای این که در یک شرکت استخدام شوید علاقه مند هستید تا به عنوان یک برنامه نویس برای خودتان کار کنید یا این که ممکن است یک فرزند داشته باشید و علاقه مند باشید تا زمان بیشتری را با او بگذرانید و به همین علت نمی توانید در شرکت ها کار کنید و باید برای خودتان کار کنید. شما به عنوان یک برنامه نویس هرآنچه که برای افزایش درآمد نیاز دارید را در اختیار دارید. مغزتان، لپ تاپ و اینترنت تنها چیزهایی هستند که شما به آنها نیاز دارید. برای افزایش درآمد برنامه نویسی می توانید استراتژی هایی که در ادامه بیان می کنیم را بررسی کنید تا متوجه شوید که کدام یک می توانند برای شما گزینه بهتری باشند.\r\nبه عنوان یک برنامه نویس، فریلنسری را آغاز کنید\r\n\r\nفریلنسرینگ می تواند برای شما بسیار مفید باشد. شما می توانید بدون داشتن یک رئیس برای خودتان کار کنید، تعداد زیادی پروژه وجود دارد که می توانید هر یک از آنها را انتخاب کنید، افرادی که تخصص زیادی دارند معمولا درآمد زیادی نیز از این طریق به دست می آورند، شما می توانید تعطیلات زیادی در طول سال داشته باشید و بسیاری از مزایای دیگر که باعث می شود تا فریلنسینگ یک شغل بسیار مفید باشد.\r\n\r\nبا این حال شما برای پیدا کردن مشتری و پروژه جدید باید نظم و انضباط زیادی داشته باشید. یکی از بزرگ ترین مزایای این شغل این است که شما می توانید در کنار شغل اصلی خود در زمان های آزادی که دارید یا در تعطیلات پروژه انجام دهید.\r\nکار روی پروفایل لینکدین\r\n\r\nیک استراتژی بهتر برای شروع کار به عنوان یک فریلنسر این است که روی پروفایل لینکدین خود کار کنید. سعی کنید با استخدام کنندگان و مشتریان قبلی خود ارتباط بگیرید، در کنفرانس ها و جلسات مختلف شرکت کنید و به دنبال پلتفرم هایی باشید که امکان کار کردن از راه دور را برای شما فراهم می کنند.\r\nدر مسابقات کدنویسی شرکت کنید\r\n\r\nبله این موضوع کاملا واقعی است. پلتفرم های اختصاصی وجود دارند که مسابقات برنامه نویسی را با جایزه های واقعی برگزار می کنند. یکی از بزرگترین این پلتفرم ها پلتفرم Topcoder است که بیش از یک میلیون عضو دارد و هر ساله مسابقات زیادی را در این زمینه برگزار می کند. این پلتفرم دارای سه محور اصلی طراحی، توسعه و علم داده است.\r\n\r\nشما می توانید روی پروژه های واقعی کار کنید که توسط بیش از 2000 نفر دیگر نیز انجام می شوند یا این که می توانید در مسابقات تک نفره شرکت کنید و با حریفان خود رقابت کنید. این کار به شما تضمین می دهد که منحنی یادگیری خود را بهبود دهید و خیلی سریع مهارت های خود را بهبود دهید.\r\n\r\nاگر به چالش های برنامه نویسی علاقه مند هستید این مسابقات می توانند برای شما بسیار جذاب و هیجان انگیز باشند. با این حال نباید فراموش کنید که این مسابقات دارای رقابت شدیدی هستند و شما نمی توانید انتظار درآمد ثابتی از آنها داشته باشید.\r\nنوشتن مطلب را آغاز کنید\r\n\r\nنوشتن مطلب می تواند یکی از بهترین راه ها برای رسیدن به مخاطبان گسترده باشد. فرصت های زیادی برای شروع نوشتن مطلب و کسب درآمد از این طریق وجود دارد که از جمله آنها می توان به موارد زیر اشاره کرد:\r\n\r\n-          می توانید وبلاگ خود را راه اندازی کنید و با استفاده از تبلیغات اقدام به کسب درآمد کنید.\r\n\r\n-          می توانید کتاب یا کتاب الکترونیکی بنویسید و آنها را به صورت رایگان بفروشید.\r\n\r\n-          می توانید در برخی پلتفرم ها مطلب بنویسید و در پلتفرم های مشارکتی آنها شرکت کنید.\r\n\r\n-          می توانید در سایت های استخدام به صورت مهمان پست ایجاد کنید. در صورت قبول شدن محتوای شما این سایت ها معمولا درآمد خوبی دارند.\r\n\r\nهیچ اشکالی ندارد که همه چیز را امتحان کنید و ببینید مردم چگونه به آنچه که می نویسید واکنش نشان می دهند. امروزه بسیاری از برنامه نویسان در پلتفرم های مختلف مطلب می نویسند و درآمد خوبی کسب می‌کنند.\r\n\r\nبا این حال نباید فراموش کنید که شما حتما باید در زمینه ای مطلب بنویسید که به آن علاقه دارید (این امر باعث می شود تا شما با انگیزه بمانید). سعی کنید به طور مداوم به نوشتن ادامه دهید و روز به روز مهارت های نوشتاری خود را ارتقاء دهید. نوشتن مقالات باکیفیت به شما کمک می کند تا بتوانید بازدید مطالب خود را چندین برابر کنید.\r\nضبط و فروش دوره های آنلاین\r\n\r\nتوانایی آموزش آنلاین به افراد یکی از مهم ترین مهارت هایی است که شما می توانید به عنوان برنامه نویس داشته باشید. این مهارت ها در سال های اخیر ظهور پیدا کرده اند و حداقل یک دهه دیگر نیز ادامه پیدا خواهند کرد.\r\n\r\nمزایای این دوره ها هم برای دانش آموزان و هم برای معلمان است. دانشجویان می توانند از میان طیف گسترده ای از انتخاب هایی که دارند بهترین گزینه را انتخاب کنند و مدرسان نیز می توانند با استفاده از این دوره ها درآمدزایی کنند.\r\n\r\nاگر شما به عنوان یک برنامه نویس تجربه یا دانش تخصصی در زمینه جاوا اسکریپت، پایتون یا هر زبان و فریم ورک دیگری دارید می توانید به دیگران آموزش دهید و از این مسئله نهایت لذت را ببرید. ایجاد دوره های آنلاین و فروش آنها می تواند درآمد خوبی را برای شما داشته باشد.\r\n\r\nپلتفرم های زیادی برای انتشار این دوره ها وجود دارند که از جمله معروف ترین آنها می توان به سایت udemy اشاره کرد. این سایت دارای 75 میلیون بازدید در ماه است و می تواند یکی از بهترین گزینه ها برای انتشار دوره شما باشد. البته پلتفرم های داخلی دیگری نیز وجود دارند که شما می توانید از آنها استفاده کنید.\r\nصحبت پایانی\r\n\r\nبرای داشتن درآمد بالا به عنوان یک برنامه نویس مهم نیست که از کدام روش استفاده کنید. شما باید استراتژی که انتخاب می کنید را دنبال کرده و در آن استقامت داشته باشید. با صرف زمان و انرژی کافی در 99 درصد مواقع شما می توانید موفق شوید و درآمد اضافی را به عنوان یک برنامه نویس داشته باشید و از زندگی خود لذت ببرید.', 'img/WallpaperGram.IR_1554000902_65651.png', '                آیا شما هم علاقه مند به افزایش درآمد خود به عنوان یک برنامه نویس هستید؟ در این مطلب...\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

DROP TABLE IF EXISTS `sample`;
CREATE TABLE IF NOT EXISTS `sample` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `src` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `sample`
--

INSERT INTO `sample` (`id`, `title`, `src`, `category`, `date`) VALUES
(6, 'وبسایت غذای ایتالیایی', 'img/8131785_3786658.jpg', 'DizainRM', '2022-10-02 08:25:20'),
(3, 'وبسایت غذا محلی', 'img/7436705_3562984.jpg', 'DizainRM', '2022-10-02 08:25:20'),
(9, 'وبسایت غذا محلی', 'img/7436705_3562984.jpg', 'DizainRM', '2022-10-02 08:25:20');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `img` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `img`, `title`, `text`) VALUES
(1, 'img/16829080_5741168.jpg', 'UI & UX', 'طراحی های خود را به ما بسپارید تا مشتری به دست آورید'),
(2, 'img/1363.jpg', 'خدمات بک اند', 'اگر می خواهید سایتتان با بالاترین امنیت کار کند خدمات مارا بپزیرید'),
(3, 'img/tablet.jpg', 'طراحی سایت', 'خدمات سایت و طراحی به صورت حرفه ای توسط تیم ما');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
CREATE TABLE IF NOT EXISTS `setting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `intro` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `copyright` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `instagram` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `facebook` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `twitter` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `pinterest` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `brand`, `title`, `intro`, `address`, `phone`, `email`, `copyright`, `instagram`, `facebook`, `twitter`, `pinterest`) VALUES
(1, ' DizainRM', '', ' وبسایت ما با پشتیبانی از وبسایت ها و شرکت های مختلف میتواند شمارا در رسیدن به رویاهایتان دنبال کند و بهترین خدمات و پشتیبانی \r\nرا به شما مشتری عزیز بدهد', ' ایران - تهران - خیابان جمهوری ', ' 021-992243', ' DizainRM@gmail.com', 'DizainRM کپی رایت پیگرد قانونی دارد', 'https://instagram.com/', 'https://facebook.com/', 'https://twitter.com/', 'https://pinterest.com/');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
CREATE TABLE IF NOT EXISTS `skills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `volume` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `title`, `volume`) VALUES
(1, 'html', '90'),
(2, 'css', '95'),
(3, 'php', '70'),
(4, 'javascript', '80');

-- --------------------------------------------------------

--
-- Table structure for table `skills2`
--

DROP TABLE IF EXISTS `skills2`;
CREATE TABLE IF NOT EXISTS `skills2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `volume` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `skills2`
--

INSERT INTO `skills2` (`id`, `title`, `volume`) VALUES
(1, 'html', '85'),
(2, 'css', '90'),
(3, 'php', '65'),
(4, 'phyton', '90');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
