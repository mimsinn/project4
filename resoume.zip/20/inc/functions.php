<?php
session_start();
ob_start();
require_once("config.php");


function showMenu()
{
    $connect = connection();
    $sql = "SELECT * FROM menu";
    $res = mysqli_query($connect, $sql);
    return $res;
}

function showSkills(){
    $connect = connection();
    $sql = "SELECT * FROM `skills`";
    $res = mysqli_query($connect,$sql);
    return $res;
}
function showSkills2(){
    $connect = connection();
    $sql = "SELECT * FROM `skills2`";
    $res = mysqli_query($connect,$sql);
    return $res;
}



// function get_gravatar($email = null){
//     $email = filter_var($email,FILTER_VALIDATE_EMAIL);
//     $hash = md5( strtolower( trim( $email ) ) );
//     $size = 150;
//     $grav_url = "https://www.gravatar.com/avatar/" . $hash . "?s=" . $size;
//     return $grav_url;
// }


function showSample(){
    $connect = connection();
    $sql = "SELECT * FROM `sample`";
    $res = mysqli_query($connect,$sql);
    return $res;
}
function showSample2(){
    $connect = connection();
    $sql = "SELECT * FROM `sample` limit 3";
    $res = mysqli_query($connect,$sql);
    return $res;
}

function showCategories(){
    $connect = connection();
    $sql = "SELECT * FROM `categories`";
    $res = mysqli_query($connect,$sql);
    return $res;
}

function showSinglePost($id = null){
    $connect = connection();
    $id = intval($id);
    $sql = "SELECT * FROM `posts` WHERE id='$id'";
    $res = mysqli_query($connect,$sql);
    $row = mysqli_fetch_assoc($res);
    return $row;
}



function showPosts(){
    $connect = connection();
    $sql = "SELECT * FROM `posts`";
    $res = mysqli_query($connect,$sql);
    return $res;
}
function showPosts2(){
    $connect = connection();
    $sql = "SELECT * FROM `posts` ORDER BY `id` DESC limit 3";
    $res = mysqli_query($connect,$sql);
    return $res;
}
function showSingleCategory($id = null){
    $connect = connection();
    $id = intval($id);
    $sql = "SELECT * FROM `categories` WHERE id='$id'";
    $res = mysqli_query($connect,$sql);
    $row = mysqli_fetch_assoc($res);
    return $row['title'];
}




function showSetting(){
    $connect= connection();
    $sql = "SELECT * FROM `setting` WHERE id=1";
    $res = mysqli_query($connect,$sql);
    $row = mysqli_fetch_assoc($res);
    return $row;
}

function showAboutmy()
{
    $connect = connection();
    $sql = "SELECT * FROM `about-my` ";
    $res = mysqli_query($connect, $sql);
    return $res;
}

function showServices()
{
    $connect = connection();
    $sql = "SELECT * FROM services";
    $res = mysqli_query($connect, $sql);
    return $res;
}

function showAbout(){
    $connect = connection();
    $sql = "SELECT * FROM `about`";
    $res = mysqli_query($connect,$sql);
    return $res;
}

function showAbout2(){
    $connect = connection();
    $sql = "SELECT * FROM `about2`";
    $res = mysqli_query($connect,$sql);
    return $res;
}
function showNumbers(){
    $connect = connection();
    $sql = "SELECT * FROM `numbers`";
    $res = mysqli_query($connect,$sql);
    return $res;
}








