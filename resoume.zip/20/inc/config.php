<?php

function connection()
{
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "myresume";
    $connect = mysqli_connect($server, $username, $password, $database);
    mysqli_set_charset($connect, "utf8");
    mysqli_query($connect, "SET NAMES 'utf8'");
    return $connect;
}


?> 