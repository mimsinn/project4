<?php
require_once("inc/functions.php");
$fullname = filter_var($_POST["fullname"], FILTER_SANITIZE_STRING);
$email = filter_var($_POST["email"], FILTER_SANITIZE_STRING);
$subject = filter_var($_POST["subject"], FILTER_SANITIZE_STRING);
$text = filter_var($_POST["text"], FILTER_SANITIZE_STRING);
if (isset($fullname) && isset($email) && isset($subject) && isset($text)) {
    if (empty($fullname) || empty($email) || empty($subject) || empty($text)) {
        $result = "لطفا تمام فیلدها را پر کنید ...";
    } else {
        $connect = connection();
        $sql = "INSERT INTO `message` (fullname,email,subject,text) VALUES('$fullname','$email','$subject','$text')";
        mysqli_query($connect, $sql);
        $result = "پیام شما با موفقیت به سیستم اضافه شد";
    }
}
echo json_encode($result);


?>