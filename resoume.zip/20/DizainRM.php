<?php
  include "inc/config.php";
  require_once "view/hadear.php";
  require_once "view/intro.php";
  require_once "view/Services.php";
  require_once "view/counter.php";
  require_once "view/Portfolio.php";
  require_once "view/Testimonials.php";
  require_once "view/blog-index.php";
  require_once "view/footer.php";

  //require_once "view/js.php";



 




 




